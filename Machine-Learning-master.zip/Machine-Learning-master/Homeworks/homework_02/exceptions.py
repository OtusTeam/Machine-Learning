
class LowFuelError():
    pass

class NotEnoughFuel():
    pass

class CargoOverload():
    pass