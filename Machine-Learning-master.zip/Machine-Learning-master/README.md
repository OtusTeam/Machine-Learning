# Machine Learning


## Курсы ML Basic:

- [ML-Basic.2021-05](https://github.com/OtusTeam/Machine-Learning/tree/ML-Basic.2021-05)
